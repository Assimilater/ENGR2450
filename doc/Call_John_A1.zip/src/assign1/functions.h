#pragma once

#include <math.h>

double displacement(double);
double singularity(double, double, double);
