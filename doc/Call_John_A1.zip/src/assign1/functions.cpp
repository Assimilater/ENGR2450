#include "functions.h"

double displacement(double x) {
    return
        (-5 * (singularity(x, 0, 4) - singularity(x, 5, 4)) / 6) +
        (15 * singularity(x, 8, 3) / 6) +
        (75 * singularity(x, 7, 2)) +
        (57 * pow(x, 3) / 6) -
        (238.25 * x);
}

double singularity(double x, double a, double n) {
    if (x <= a) { return 0; }
    return pow(x - a, n);
}
