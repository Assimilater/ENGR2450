#pragma once

#include <unordered_map>
#include <functional>

std::unordered_map<double, double> Eulers(std::function<double(double, double)>, double, double, double, double);
