//-----------------------------------------------------------------------+
// John Call - A01283897                                                 |
// Driver for ENGR 2450 homework                                         |
//-----------------------------------------------------------------------+
#include "assign5\assign5.hpp"
#include <iostream>

int main() {
    assign5::main();

    system("pause");
    return 0;
}
