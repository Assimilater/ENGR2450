#pragma once

namespace assign5 {
    void main();
};
