#include "assign3.h"
#include "a3p1.h"
#include "a3p3.h"
#include "a3p4.h"

void assign3::main() {
    assign3::Problem1();
    assign3::Problem3();
    assign3::Problem4();
}
