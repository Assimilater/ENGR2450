#pragma once

namespace assign3 {
    enum MatrixError {
        GOOD = 0,
        INV_DIM = 1,
        SINGULAR = 2
    };

    void main();
}
