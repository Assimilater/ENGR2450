//-----------------------------------------------------------------------+
// John Call - A01283897                                                 |
// Driver for ENGR 2450 homework                                         |
//-----------------------------------------------------------------------+
#include "assign3\assign3.h"
#include <iostream>

int main() {
    assign3::main();

    system("pause");
    return 0;
}
