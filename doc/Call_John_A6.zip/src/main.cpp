//-----------------------------------------------------------------------+
// John Call - A01283897                                                 |
// Driver for ENGR 2450 homework                                         |
//-----------------------------------------------------------------------+
#include "assign6\assign6.hpp"
#include <iostream>

int main() {
    assign6::main();

    system("pause");
    return 0;
}
