#pragma once

namespace assign6 {
    void main();
};
