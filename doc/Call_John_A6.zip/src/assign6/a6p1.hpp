#pragma once

namespace assign6 {
    void Prob1();
}
