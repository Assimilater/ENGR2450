#include "assign6.hpp"
#include "a6p1.hpp"
#include "a6p4.hpp"
#include "a6p5.hpp"

void assign6::main() {
    Prob1();
    Prob4();
    Prob5();
}
