#pragma once

namespace assign4 {
    void Problem2();
}
