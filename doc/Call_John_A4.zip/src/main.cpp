//-----------------------------------------------------------------------+
// John Call - A01283897                                                 |
// Driver for ENGR 2450 homework                                         |
//-----------------------------------------------------------------------+
#include "assign4\assign4.hpp"
#include <iostream>

int main() {
    assign4::main();

    system("pause");
    return 0;
}
