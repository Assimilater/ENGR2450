//---------------------------------------------------------------------------------+
// John Call - A01283897                                                           |
// Driver for ENGR 2450 homework                                                   |
//---------------------------------------------------------------------------------+
#include "assign1\assign1.h"
#include "assign2\assign2.h"
#include <iostream>

int main() {
    //assign1::main();
    assign2::main();

    system("pause");
    return 0;
}
