#pragma once

namespace assign1 {
    double singularity(double, double, double);
    double displacement(double);

    void Problem1();
    void Problem2();
    void Problem3();

    void main();
}
